Synthetic roads, CC0-1.0. Shapefile is in shanghai/transport/.
